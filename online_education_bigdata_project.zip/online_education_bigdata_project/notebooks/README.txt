
This folder can contain Jupyter notebooks for:
- Exploratory Data Analysis
- Machine Learning Models
- Visualization Experiments
